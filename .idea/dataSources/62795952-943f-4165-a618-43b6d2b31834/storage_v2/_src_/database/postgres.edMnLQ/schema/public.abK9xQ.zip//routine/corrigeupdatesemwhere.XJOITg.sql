create function corrigeupdatesemwhere(tipo character varying) returns text
    language plpgsql
as
$$
BEGIN
	IF tipo = 'A' THEN
		RETURN salario = 22.0;
	ELSIF tipo = 'B' THEN
		RETURN salario = 75.0;
	ELSIF tipo = 'C' THEN
		RETURN salario = 53.0;
	ELSE
		RETURN 'Salario não conhecido';
	END IF;
END;
$$;

alter function corrigeupdatesemwhere(varchar) owner to postgres;

